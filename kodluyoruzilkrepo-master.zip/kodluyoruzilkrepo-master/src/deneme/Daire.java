package deneme;public class Daire {
}
